package com.sin.lifesim;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.view.View;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    String n="udaje";
    final SharedPreferences data=getPreferences(MODE_PRIVATE);
            SharedPreferences.Editor editor=data.edit();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         String dat=data.getString("n");
    }
    public void click(View view){

    }
}
